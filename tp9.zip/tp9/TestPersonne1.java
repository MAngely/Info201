import personne_tp9.*;
import java.util.*;

/**
 * Classe permettant de tester les classes du package personne.
 * @author Cyril Rabat
 * @version 18/04/2016
 */
public class TestPersonne1 {
    
    public static Scanner clavier = new Scanner(System.in);
    
    /**
     * Création d'une personne depuis des informations saisies au clavier.
     * @return la personne créée
     */
    public static Personne creerPersonne() {
        String nom, prenom;
        
        System.out.println("Création d'une personne :");
        System.out.print("Nom               : ");
        nom = clavier.nextLine();
        System.out.print("Prénom            : ");
        prenom = clavier.nextLine();

        return new Personne(nom, prenom);
    }
    /**
     * Création d'un étudiant depuis des informations saisies au clavier.
     * @return l'étudiant créé
     */
    public static Etudiant creerEtudiant() {
        String nom, prenom;
        int numero;
        
        System.out.println("Création d'un étudiant :");
        System.out.print("Nom               : ");
        nom = clavier.nextLine();
        System.out.print("Prénom            : ");
        prenom = clavier.nextLine();
        System.out.print("Numéro d'étudiant : ");
        numero = clavier.nextInt();
        clavier.nextLine(); /* Vidage du tampon */

        return new Etudiant(nom, prenom, numero);
    }

    /**
     * Création d'un enseignant depuis des informations saisies au clavier.
     * @return l'enseignant créé
     */
    public static Enseignant creerEnseignant() {
        String nom, prenom;
        double salaire;
        
        System.out.println("Création d'un enseignant :");
        System.out.print("Nom               : ");
        nom = clavier.nextLine();
        System.out.print("Prénom            : ");
        prenom = clavier.nextLine();
        System.out.print("Salaire           : ");
        salaire = clavier.nextDouble();
        clavier.nextLine();        
        
        return new Enseignant(nom, prenom, salaire);
    }

    /**
     * Création d'un vacataire depuis des informations saisies au clavier.
     * @return le vacataire créé
     */
    public static Enseignant creerVacataire() {
        String nom, prenom, entreprise;
        double salaire;
        
        System.out.println("Création d'un vacataire :");
        System.out.print("Nom               : ");
        nom = clavier.nextLine();
        System.out.print("Prénom            : ");
        prenom = clavier.nextLine();
        System.out.print("Salaire           : ");
        salaire = clavier.nextDouble();
        System.out.print("Entreprise      : ");
        entreprise = clavier.nextLine();
        clavier.nextLine();

        return new Vacataire(nom,prenom,salaire,entreprise);
    }
    
    /** 
     * Méthode principale.
     * @param args les arguments
     */
    public static void main(String args[]) {
        Personne tableau[] = new Personne[4];

        /* Initialisation du tableau */
        tableau[0] = creerPersonne();
        tableau[1] = creerEtudiant();
        tableau[2] = creerEnseignant();
        tableau[3] = creerVacataire();
        
        /* Affichage du contenu du tableau */
        System.out.println("Résumé : ");
        for(int i = 0; i < tableau.length; i++)
            System.out.println(tableau[i].toString());


        Personne tableau1[] = new Personne[4];

        tableau1[0].clone(tableau[0]);
        tableau1[1].clone(tableau[1]);
        tableau1[2].clone(tableau[2]);
        tableau1[3].clone(tableau[3]);

        for(int i = 0; i < tableau.length; i++)
            System.out.println(tableau1[i].toString());
    }
    
}