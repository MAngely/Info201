package personne_tp9;

/**
 * Classe représentant un étudiant.
 * @author Cyril Rabat
 * @version 18/04/2016
 */
public class Etudiant extends Personne {
    
    private int numeroEtudiant;
    
    /**
     * Constructeur par initialisation.
     * @param nom le nom de l'étudiant
     * @param prenom le prénom de l'étudiant
     * @param numero le numéro d'étudiant
     */
    public Etudiant(String nom, String prenom, int numero) {
        super(nom, prenom);
        this.numeroEtudiant = numero;
    }

    public Etudiant(Etudiant e){
        this(e.getNom(),e.getPrenom(),e.numeroEtudiant);
    }
    
     /**
     * Retourne le numéro d'étudiant de l'étudiant.
     * @return le numéro d'étudiant
     */
    public int getNumeroEtudiant() {
        return numeroEtudiant;
    } 

    public String toString(){
        return "Etudant "+super.toString()+", numero "+numeroEtudiant;
    }

    public void afficher(){
        System.out.println(toString());
    }
 
}